/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        bg: '#0a0e14',
        surface: '#111722',
        surface2: '#161d2b',
        border: '#232b3a',
        primary: '#22d3ee',
        secondary: '#a78bfa',
        accent: '#f472b6',
        success: '#4ade80',
        warning: '#facc15',
        danger: '#fb7185'
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace']
      },
      boxShadow: {
        glow: '0 0 20px rgba(34, 211, 238, 0.3)',
        glowPink: '0 0 20px rgba(244, 114, 182, 0.3)'
      },
      keyframes: {
        fadeIn: { '0%': { opacity: 0, transform: 'translateY(8px)' }, '100%': { opacity: 1, transform: 'translateY(0)' } },
        pulseGlow: { '0%, 100%': { boxShadow: '0 0 5px rgba(34,211,238,0.4)' }, '50%': { boxShadow: '0 0 25px rgba(34,211,238,0.8)' } },
        shake: { '0%, 100%': { transform: 'translateX(0)' }, '25%': { transform: 'translateX(-6px)' }, '75%': { transform: 'translateX(6px)' } }
      },
      animation: {
        fadeIn: 'fadeIn 0.4s ease-out',
        pulseGlow: 'pulseGlow 2s infinite',
        shake: 'shake 0.4s ease-in-out'
      }
    }
  },
  plugins: []
}
