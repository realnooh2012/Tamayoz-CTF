import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { FaFlag, FaTrophy, FaBullhorn, FaChartLine } from 'react-icons/fa'
import api from '../api/axios'
import { useAuth } from '../context/AuthContext'
import Loader from '../components/Loader'
import Countdown from '../components/Countdown'

export default function Dashboard() {
  const { user } = useAuth()
  const [announcements, setAnnouncements] = useState([])
  const [scoreboard, setScoreboard] = useState([])
  const [loading, setLoading] = useState(true)

  const endDate = new Date()
  endDate.setDate(endDate.getDate() + 3)

  useEffect(() => {
    Promise.all([api.get('/announcements'), api.get('/scoreboard')])
      .then(([a, s]) => {
        setAnnouncements(a.data.announcements.slice(0, 3))
        setScoreboard(s.data.scoreboard.slice(0, 5))
      })
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <Loader fullscreen />

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 animate-fadeIn">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
        <h1 className="text-3xl font-extrabold mb-1">Welcome back, <span className="gradient-text">{user.username}</span></h1>
        <p className="text-slate-400">Ready to hack? Here's what's happening.</p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="card p-6 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary text-xl"><FaFlag /></div>
          <div>
            <p className="text-slate-400 text-sm">Your Points</p>
            <p className="text-2xl font-bold">{user.points}</p>
          </div>
        </div>
        <div className="card p-6 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center text-secondary text-xl"><FaChartLine /></div>
          <div>
            <p className="text-slate-400 text-sm">Rank</p>
            <p className="text-2xl font-bold">{scoreboard.findIndex(s => s.username === user.username) + 1 || '—'}</p>
          </div>
        </div>
        <div className="card p-6">
          <p className="text-slate-400 text-sm mb-2">Competition Ends In</p>
          <Countdown targetDate={endDate.getTime()} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-bold text-lg flex items-center gap-2"><FaTrophy className="text-warning" /> Top Hackers</h2>
            <Link to="/scoreboard" className="text-primary text-sm hover:underline">View all</Link>
          </div>
          <div className="space-y-2">
            {scoreboard.map((s) => (
              <div key={s.id} className="flex items-center justify-between bg-surface2 rounded-lg px-4 py-3">
                <div className="flex items-center gap-3">
                  <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${s.rank === 1 ? 'bg-warning text-bg' : s.rank === 2 ? 'bg-slate-300 text-bg' : s.rank === 3 ? 'bg-orange-400 text-bg' : 'bg-surface text-slate-400'}`}>{s.rank}</span>
                  <span className="font-medium">{s.username}</span>
                </div>
                <span className="text-primary font-bold">{s.points} pts</span>
              </div>
            ))}
            {scoreboard.length === 0 && <p className="text-slate-500 text-sm">No solves yet. Be the first!</p>}
          </div>
        </div>

        <div className="card p-6">
          <h2 className="font-bold text-lg flex items-center gap-2 mb-4"><FaBullhorn className="text-accent" /> Announcements</h2>
          <div className="space-y-4">
            {announcements.map((a) => (
              <div key={a.id} className="border-l-2 border-accent pl-3">
                <p className="font-semibold text-sm">{a.title}</p>
                <p className="text-slate-400 text-sm mt-1">{a.content}</p>
              </div>
            ))}
            {announcements.length === 0 && <p className="text-slate-500 text-sm">No announcements yet.</p>}
          </div>
        </div>
      </div>

      <div className="mt-8 text-center">
        <Link to="/challenges" className="btn-primary inline-flex items-center gap-2 px-8 py-3 text-lg">
          <FaFlag /> Start Solving Challenges
        </Link>
      </div>
    </div>
  )
}
