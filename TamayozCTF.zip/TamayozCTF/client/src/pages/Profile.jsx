import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaUserCircle, FaFlag, FaCalendar } from 'react-icons/fa'
import api from '../api/axios'
import Loader from '../components/Loader'

export default function Profile() {
  const { username } = useParams()
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    setLoading(true)
    api.get(`/profile/${username}`).then((res) => setData(res.data)).finally(() => setLoading(false))
  }, [username])

  if (loading) return <Loader fullscreen />
  if (!data) return <div className="text-center py-20 text-slate-500">User not found.</div>

  const { user, solves } = data

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 animate-fadeIn">
      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="card p-8 mb-6 flex flex-col sm:flex-row items-center gap-6">
        <FaUserCircle className="text-7xl text-primary" />
        <div className="text-center sm:text-left">
          <h1 className="text-2xl font-extrabold">{user.username}</h1>
          {user.bio && <p className="text-slate-400 mt-1">{user.bio}</p>}
          <div className="flex items-center gap-4 mt-3 text-sm text-slate-400 justify-center sm:justify-start">
            <span className="flex items-center gap-1"><FaFlag className="text-primary" /> {user.points} pts</span>
            <span className="flex items-center gap-1"><FaCalendar /> Joined {new Date(user.created_at).toLocaleDateString()}</span>
          </div>
        </div>
      </motion.div>

      <div className="card p-6">
        <h2 className="font-bold text-lg mb-4">Solved Challenges ({solves.length})</h2>
        <div className="space-y-2">
          {solves.map((s, i) => (
            <div key={i} className="flex items-center justify-between bg-surface2 rounded-lg px-4 py-3">
              <div>
                <p className="font-medium">{s.title}</p>
                <p className="text-xs text-slate-500">{s.category} • {new Date(s.created_at).toLocaleString()}</p>
              </div>
              <span className="text-primary font-bold">+{s.points}</span>
            </div>
          ))}
          {solves.length === 0 && <p className="text-slate-500 text-sm">No solves yet.</p>}
        </div>
      </div>
    </div>
  )
}
