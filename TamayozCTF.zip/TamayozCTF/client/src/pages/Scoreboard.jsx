import React, { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { FaCrown, FaMedal } from 'react-icons/fa'
import api from '../api/axios'
import { useSocket } from '../context/SocketContext'
import Loader from '../components/Loader'

export default function Scoreboard() {
  const [scoreboard, setScoreboard] = useState([])
  const [loading, setLoading] = useState(true)
  const socket = useSocket()

  const load = () => api.get('/scoreboard').then((res) => setScoreboard(res.data.scoreboard)).finally(() => setLoading(false))

  useEffect(() => { load() }, [])

  useEffect(() => {
    if (!socket) return
    socket.on('scoreboard:update', load)
    return () => socket.off('scoreboard:update', load)
  }, [socket])

  if (loading) return <Loader fullscreen />

  const podium = scoreboard.slice(0, 3)
  const rest = scoreboard.slice(3)

  const podiumColors = ['from-warning to-yellow-600', 'from-slate-300 to-slate-500', 'from-orange-400 to-orange-700']

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 animate-fadeIn">
      <h1 className="text-3xl font-extrabold mb-8 flex items-center gap-3"><FaCrown className="text-warning" /> Scoreboard</h1>

      {podium.length > 0 && (
        <div className="grid grid-cols-3 gap-3 mb-10 items-end">
          {[podium[1], podium[0], podium[2]].filter(Boolean).map((p, idx) => {
            const rank = p.rank
            const height = rank === 1 ? 'h-40' : rank === 2 ? 'h-32' : 'h-24'
            return (
              <motion.div key={p.id} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.1 }} className="flex flex-col items-center">
                <FaMedal className={`text-2xl mb-2 ${rank === 1 ? 'text-warning' : rank === 2 ? 'text-slate-300' : 'text-orange-400'}`} />
                <p className="font-bold text-center mb-1 truncate max-w-[100px]">{p.username}</p>
                <p className="text-primary text-sm mb-2">{p.points} pts</p>
                <div className={`w-full ${height} rounded-t-lg bg-gradient-to-t ${podiumColors[rank - 1]} flex items-start justify-center pt-2`}>
                  <span className="text-2xl font-extrabold text-bg">{rank}</span>
                </div>
              </motion.div>
            )
          })}
        </div>
      )}

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-surface2 text-slate-400">
            <tr>
              <th className="text-left px-4 py-3">Rank</th>
              <th className="text-left px-4 py-3">Username</th>
              <th className="text-right px-4 py-3">Points</th>
              <th className="text-right px-4 py-3 hidden sm:table-cell">Solves</th>
              <th className="text-right px-4 py-3 hidden md:table-cell">Last Solve</th>
            </tr>
          </thead>
          <tbody>
            {scoreboard.map((s) => (
              <tr key={s.id} className="border-t border-border hover:bg-surface2/50 transition-colors">
                <td className="px-4 py-3 font-bold">{s.rank}</td>
                <td className="px-4 py-3">{s.username}</td>
                <td className="px-4 py-3 text-right text-primary font-bold">{s.points}</td>
                <td className="px-4 py-3 text-right hidden sm:table-cell text-slate-400">{s.solve_count}</td>
                <td className="px-4 py-3 text-right hidden md:table-cell text-slate-500 text-xs">
                  {s.last_solve ? new Date(s.last_solve).toLocaleString() : '—'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {scoreboard.length === 0 && <p className="text-center text-slate-500 py-10">No scores yet.</p>}
      </div>
    </div>
  )
}
