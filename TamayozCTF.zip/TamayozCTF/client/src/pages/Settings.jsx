import React, { useState } from 'react'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { FaUserEdit, FaKey } from 'react-icons/fa'
import api from '../api/axios'
import { useAuth } from '../context/AuthContext'

export default function Settings() {
  const { user } = useAuth()
  const [bio, setBio] = useState('')
  const [avatar, setAvatar] = useState('')
  const [passwords, setPasswords] = useState({ currentPassword: '', newPassword: '' })
  const [savingProfile, setSavingProfile] = useState(false)
  const [savingPassword, setSavingPassword] = useState(false)

  const saveProfile = async (e) => {
    e.preventDefault()
    setSavingProfile(true)
    try {
      await api.put('/profile/me', { bio, avatar })
      toast.success('Profile updated')
    } catch (err) {
      toast.error(err.response?.data?.error || 'Update failed')
    } finally {
      setSavingProfile(false)
    }
  }

  const savePassword = async (e) => {
    e.preventDefault()
    setSavingPassword(true)
    try {
      await api.put('/profile/me/password', passwords)
      toast.success('Password changed')
      setPasswords({ currentPassword: '', newPassword: '' })
    } catch (err) {
      toast.error(err.response?.data?.error || 'Password change failed')
    } finally {
      setSavingPassword(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8 animate-fadeIn">
      <h1 className="text-3xl font-extrabold mb-8">Settings</h1>

      <motion.form initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} onSubmit={saveProfile} className="card p-6 mb-6">
        <h2 className="font-bold text-lg mb-4 flex items-center gap-2"><FaUserEdit className="text-primary" /> Profile</h2>
        <label className="text-sm text-slate-400 mb-1 block">Bio</label>
        <textarea className="input-field mb-4" rows={3} value={bio} onChange={(e) => setBio(e.target.value)} placeholder="Tell us about yourself..." />
        <label className="text-sm text-slate-400 mb-1 block">Avatar URL</label>
        <input className="input-field mb-4" value={avatar} onChange={(e) => setAvatar(e.target.value)} placeholder="https://..." />
        <button className="btn-primary" disabled={savingProfile}>{savingProfile ? 'Saving...' : 'Save Profile'}</button>
      </motion.form>

      <motion.form initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} onSubmit={savePassword} className="card p-6">
        <h2 className="font-bold text-lg mb-4 flex items-center gap-2"><FaKey className="text-secondary" /> Change Password</h2>
        <label className="text-sm text-slate-400 mb-1 block">Current Password</label>
        <input type="password" className="input-field mb-4" value={passwords.currentPassword} onChange={(e) => setPasswords({ ...passwords, currentPassword: e.target.value })} required />
        <label className="text-sm text-slate-400 mb-1 block">New Password</label>
        <input type="password" className="input-field mb-4" value={passwords.newPassword} onChange={(e) => setPasswords({ ...passwords, newPassword: e.target.value })} required minLength={8} />
        <button className="btn-primary" disabled={savingPassword}>{savingPassword ? 'Updating...' : 'Update Password'}</button>
      </motion.form>
    </div>
  )
}
