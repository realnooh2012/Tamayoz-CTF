import React, { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import toast from 'react-hot-toast'
import { FaFlag, FaDownload, FaLightbulb, FaCheckCircle, FaTimesCircle, FaLock, FaTint } from 'react-icons/fa'
import api from '../api/axios'
import { useAuth } from '../context/AuthContext'
import Loader from '../components/Loader'

export default function ChallengeDetail() {
  const { id } = useParams()
  const { user, updateUserPoints } = useAuth()
  const [challenge, setChallenge] = useState(null)
  const [flag, setFlag] = useState('')
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)
  const [feedback, setFeedback] = useState(null) // 'correct' | 'incorrect'

  const load = () => {
    api.get(`/challenges/${id}`).then((res) => setChallenge(res.data.challenge)).finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [id])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!flag.trim()) return
    setSubmitting(true)
    setFeedback(null)
    try {
      const res = await api.post(`/challenges/${id}/submit`, { flag })
      if (res.data.correct) {
        setFeedback('correct')
        toast.success(res.data.message)
        if (res.data.totalPoints !== undefined) updateUserPoints(res.data.totalPoints)
        setFlag('')
        load()
      } else {
        setFeedback('incorrect')
        toast.error(res.data.message || 'Incorrect flag')
      }
    } catch (err) {
      toast.error(err.response?.data?.error || 'Submission failed')
      setFeedback('incorrect')
    } finally {
      setSubmitting(false)
      setTimeout(() => setFeedback(null), 900)
    }
  }

  const unlockHint = async (hintId) => {
    try {
      const res = await api.post(`/challenges/hints/${hintId}/unlock`)
      toast.success(res.data.alreadyUnlocked ? 'Hint already unlocked' : `Hint unlocked (-${res.data.costPaid} pts)`)
      load()
    } catch (err) {
      toast.error(err.response?.data?.error || 'Could not unlock hint')
    }
  }

  if (loading) return <Loader fullscreen />
  if (!challenge) return <div className="text-center py-20 text-slate-500">Challenge not found.</div>

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 animate-fadeIn">
      <Link to="/challenges" className="text-primary text-sm hover:underline">← Back to challenges</Link>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className={`card p-8 mt-4 ${feedback === 'incorrect' ? 'animate-shake border-danger/60' : feedback === 'correct' ? 'border-success/60' : ''}`}
      >
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full border" style={{ borderColor: challenge.category_color, color: challenge.category_color }}>
            {challenge.category}
          </span>
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full border border-border text-slate-400">{challenge.difficulty}</span>
          {challenge.first_blood && (
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full border border-danger/40 text-danger bg-danger/10 flex items-center gap-1">
              <FaTint /> First Blood: {challenge.first_blood}
            </span>
          )}
        </div>

        <h1 className="text-3xl font-extrabold mb-2">{challenge.title}</h1>
        <p className="text-primary font-bold mb-6 flex items-center gap-1"><FaFlag /> {challenge.points} points</p>

        <p className="text-slate-300 whitespace-pre-wrap leading-relaxed mb-6">{challenge.description}</p>

        {challenge.file_path && (
          <a href={challenge.file_path} download className="btn-secondary inline-flex items-center gap-2 mb-6">
            <FaDownload /> Download attachment
          </a>
        )}

        {challenge.hints && challenge.hints.length > 0 && (
          <div className="mb-6">
            <h3 className="font-semibold mb-2 flex items-center gap-2"><FaLightbulb className="text-warning" /> Hints</h3>
            <div className="space-y-2">
              {challenge.hints.map((h) => (
                <div key={h.id} className="bg-surface2 border border-border rounded-lg px-4 py-3">
                  {h.unlocked ? (
                    <p className="text-slate-300 text-sm">{h.content}</p>
                  ) : (
                    <button onClick={() => unlockHint(h.id)} className="flex items-center gap-2 text-sm text-warning hover:underline">
                      <FaLock /> Unlock for {h.cost} points
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {challenge.solved ? (
          <div className="flex items-center gap-2 text-success font-semibold bg-success/10 border border-success/30 rounded-lg px-4 py-3">
            <FaCheckCircle /> You've already solved this challenge!
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
            <input
              className="input-field font-mono flex-1"
              placeholder="TAMAYOZ{...}"
              value={flag}
              onChange={(e) => setFlag(e.target.value)}
              required
            />
            <button className="btn-primary flex items-center gap-2 justify-center" disabled={submitting}>
              <AnimatePresence mode="wait">
                {feedback === 'correct' ? (
                  <motion.span key="ok" initial={{ scale: 0 }} animate={{ scale: 1 }} className="flex items-center gap-2"><FaCheckCircle /> Correct!</motion.span>
                ) : feedback === 'incorrect' ? (
                  <motion.span key="no" initial={{ scale: 0 }} animate={{ scale: 1 }} className="flex items-center gap-2"><FaTimesCircle /> Wrong</motion.span>
                ) : (
                  <motion.span key="submit">{submitting ? 'Checking...' : 'Submit Flag'}</motion.span>
                )}
              </AnimatePresence>
            </button>
          </form>
        )}
      </motion.div>
    </div>
  )
}
