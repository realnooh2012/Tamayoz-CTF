import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { FaExclamationTriangle } from 'react-icons/fa'

export default function NotFound() {
  return (
    <div className="min-h-[calc(100vh-4rem)] flex flex-col items-center justify-center px-4 text-center">
      <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }}>
        <FaExclamationTriangle className="text-6xl text-warning mx-auto mb-4" />
        <h1 className="text-6xl font-extrabold gradient-text mb-2">404</h1>
        <p className="text-slate-400 mb-6">This flag doesn't exist. Maybe it's hidden elsewhere.</p>
        <Link to="/dashboard" className="btn-primary">Return to Dashboard</Link>
      </motion.div>
    </div>
  )
}
