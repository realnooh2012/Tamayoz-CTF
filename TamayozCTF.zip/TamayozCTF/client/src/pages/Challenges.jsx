import React, { useEffect, useState, useMemo } from 'react'
import { motion } from 'framer-motion'
import { FaSearch } from 'react-icons/fa'
import api from '../api/axios'
import Loader from '../components/Loader'
import ChallengeCard from '../components/ChallengeCard'

export default function Challenges() {
  const [challenges, setChallenges] = useState([])
  const [categories, setCategories] = useState([])
  const [search, setSearch] = useState('')
  const [activeCategory, setActiveCategory] = useState('All')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([api.get('/challenges'), api.get('/challenges/categories')])
      .then(([c, cat]) => {
        setChallenges(c.data.challenges)
        setCategories(cat.data.categories)
      })
      .finally(() => setLoading(false))
  }, [])

  const filtered = useMemo(() => {
    return challenges.filter((c) => {
      const matchesSearch = c.title.toLowerCase().includes(search.toLowerCase())
      const matchesCategory = activeCategory === 'All' || c.category === activeCategory
      return matchesSearch && matchesCategory
    })
  }, [challenges, search, activeCategory])

  if (loading) return <Loader fullscreen />

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 animate-fadeIn">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <h1 className="text-3xl font-extrabold">Challenges</h1>
        <div className="relative w-full sm:w-72">
          <FaSearch className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input className="input-field pl-10" placeholder="Search challenges..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-8">
        {['All', ...categories.map((c) => c.name)].map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-all ${
              activeCategory === cat ? 'bg-primary text-bg border-primary' : 'border-border text-slate-300 hover:border-primary/50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-20 text-slate-500">No challenges found.</div>
      ) : (
        <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {filtered.map((c) => <ChallengeCard key={c.id} challenge={c} />)}
        </motion.div>
      )}
    </div>
  )
}
