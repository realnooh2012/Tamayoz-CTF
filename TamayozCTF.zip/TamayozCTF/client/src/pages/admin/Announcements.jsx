import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { FaTrash, FaBullhorn } from 'react-icons/fa'
import api from '../../api/axios'
import Loader from '../../components/Loader'

export default function Announcements() {
  const [announcements, setAnnouncements] = useState([])
  const [form, setForm] = useState({ title: '', content: '' })
  const [loading, setLoading] = useState(true)

  const load = () => api.get('/announcements').then((res) => setAnnouncements(res.data.announcements)).finally(() => setLoading(false))

  useEffect(() => { load() }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      await api.post('/announcements', form)
      toast.success('Announcement posted')
      setForm({ title: '', content: '' })
      load()
    } catch (err) {
      toast.error('Failed to post')
    }
  }

  const handleDelete = async (id) => {
    try {
      await api.delete(`/announcements/${id}`)
      toast.success('Deleted')
      load()
    } catch (err) {
      toast.error('Delete failed')
    }
  }

  if (loading) return <Loader fullscreen />

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 animate-fadeIn">
      <Link to="/admin" className="text-primary text-sm hover:underline">← Admin Panel</Link>
      <h1 className="text-3xl font-extrabold mt-1 mb-6 flex items-center gap-2"><FaBullhorn className="text-accent" /> Announcements</h1>

      <motion.form initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} onSubmit={handleSubmit} className="card p-6 mb-6">
        <input className="input-field mb-3" placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
        <textarea className="input-field mb-3" rows={3} placeholder="Content" value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} required />
        <button className="btn-primary">Post Announcement</button>
      </motion.form>

      <div className="space-y-3">
        {announcements.map((a) => (
          <div key={a.id} className="card p-4 flex items-start justify-between gap-4">
            <div>
              <p className="font-semibold">{a.title}</p>
              <p className="text-slate-400 text-sm mt-1">{a.content}</p>
              <p className="text-xs text-slate-600 mt-2">{new Date(a.created_at).toLocaleString()}</p>
            </div>
            <button onClick={() => handleDelete(a.id)} className="text-danger shrink-0"><FaTrash /></button>
          </div>
        ))}
        {announcements.length === 0 && <p className="text-slate-500 text-sm">No announcements yet.</p>}
      </div>
    </div>
  )
}
