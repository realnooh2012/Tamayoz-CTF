import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import toast from 'react-hot-toast'
import { FaPlus, FaEdit, FaTrash, FaEye, FaEyeSlash, FaTimes } from 'react-icons/fa'
import api from '../../api/axios'
import Loader from '../../components/Loader'

const emptyForm = { title: '', category_id: '', description: '', points: 100, flag: '', difficulty: 'easy', visible: true, file: null }

export default function ManageChallenges() {
  const [challenges, setChallenges] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState(emptyForm)

  const load = () => {
    Promise.all([api.get('/admin/challenges'), api.get('/challenges/categories')])
      .then(([c, cat]) => { setChallenges(c.data.challenges); setCategories(cat.data.categories) })
      .finally(() => setLoading(false))
  }

  useEffect(() => { load() }, [])

  const openCreate = () => { setEditing(null); setForm(emptyForm); setShowForm(true) }
  const openEdit = (c) => {
    setEditing(c)
    setForm({ title: c.title, category_id: c.category_id || '', description: c.description, points: c.points, flag: c.flag, difficulty: c.difficulty, visible: !!c.visible, file: null })
    setShowForm(true)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const fd = new FormData()
    Object.entries(form).forEach(([k, v]) => {
      if (k === 'file' && v) fd.append('file', v)
      else if (k !== 'file') fd.append(k, v)
    })
    try {
      if (editing) {
        await api.put(`/admin/challenges/${editing.id}`, fd)
        toast.success('Challenge updated')
      } else {
        await api.post('/admin/challenges', fd)
        toast.success('Challenge created')
      }
      setShowForm(false)
      load()
    } catch (err) {
      toast.error(err.response?.data?.error || 'Save failed')
    }
  }

  const handleDelete = async (id) => {
    if (!confirm('Delete this challenge permanently?')) return
    try {
      await api.delete(`/admin/challenges/${id}`)
      toast.success('Challenge deleted')
      load()
    } catch (err) {
      toast.error('Delete failed')
    }
  }

  if (loading) return <Loader fullscreen />

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 animate-fadeIn">
      <div className="flex items-center justify-between mb-6">
        <div>
          <Link to="/admin" className="text-primary text-sm hover:underline">← Admin Panel</Link>
          <h1 className="text-3xl font-extrabold mt-1">Manage Challenges</h1>
        </div>
        <button onClick={openCreate} className="btn-primary flex items-center gap-2"><FaPlus /> New Challenge</button>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-surface2 text-slate-400">
            <tr>
              <th className="text-left px-4 py-3">Title</th>
              <th className="text-left px-4 py-3">Category</th>
              <th className="text-right px-4 py-3">Points</th>
              <th className="text-center px-4 py-3">Visible</th>
              <th className="text-right px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {challenges.map((c) => (
              <tr key={c.id} className="border-t border-border">
                <td className="px-4 py-3 font-medium">{c.title}</td>
                <td className="px-4 py-3 text-slate-400">{c.category_name || '—'}</td>
                <td className="px-4 py-3 text-right text-primary font-bold">{c.points}</td>
                <td className="px-4 py-3 text-center">{c.visible ? <FaEye className="inline text-success" /> : <FaEyeSlash className="inline text-slate-500" />}</td>
                <td className="px-4 py-3 text-right">
                  <button onClick={() => openEdit(c)} className="text-primary mr-3"><FaEdit /></button>
                  <button onClick={() => handleDelete(c.id)} className="text-danger"><FaTrash /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
            <motion.form
              initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()} onSubmit={handleSubmit}
              className="card p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold text-lg">{editing ? 'Edit Challenge' : 'New Challenge'}</h2>
                <button type="button" onClick={() => setShowForm(false)}><FaTimes /></button>
              </div>

              <input className="input-field mb-3" placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />

              <select className="input-field mb-3" value={form.category_id} onChange={(e) => setForm({ ...form, category_id: e.target.value })}>
                <option value="">No category</option>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>

              <textarea className="input-field mb-3" rows={4} placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} required />

              <div className="grid grid-cols-2 gap-3 mb-3">
                <input type="number" className="input-field" placeholder="Points" value={form.points} onChange={(e) => setForm({ ...form, points: e.target.value })} required />
                <select className="input-field" value={form.difficulty} onChange={(e) => setForm({ ...form, difficulty: e.target.value })}>
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>

              <input className="input-field mb-3 font-mono" placeholder="Flag e.g. TAMAYOZ{...}" value={form.flag} onChange={(e) => setForm({ ...form, flag: e.target.value })} required />

              <label className="text-sm text-slate-400 mb-1 block">Attachment (optional)</label>
              <input type="file" className="input-field mb-3" onChange={(e) => setForm({ ...form, file: e.target.files[0] })} />

              <label className="flex items-center gap-2 mb-4 text-sm">
                <input type="checkbox" checked={form.visible} onChange={(e) => setForm({ ...form, visible: e.target.checked })} /> Visible to players
              </label>

              <button className="btn-primary w-full">{editing ? 'Save Changes' : 'Create Challenge'}</button>
            </motion.form>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
