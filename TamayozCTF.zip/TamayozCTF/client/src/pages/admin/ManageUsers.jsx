import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import toast from 'react-hot-toast'
import { FaTrash, FaUserShield, FaUser } from 'react-icons/fa'
import api from '../../api/axios'
import Loader from '../../components/Loader'
import { useAuth } from '../../context/AuthContext'

export default function ManageUsers() {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const { user: currentUser } = useAuth()

  const load = () => api.get('/admin/users').then((res) => setUsers(res.data.users)).finally(() => setLoading(false))

  useEffect(() => { load() }, [])

  const toggleAdmin = async (u) => {
    try {
      await api.put(`/admin/users/${u.id}/admin`, { is_admin: !u.is_admin })
      toast.success(`${u.username} is now ${!u.is_admin ? 'an admin' : 'a regular user'}`)
      load()
    } catch (err) {
      toast.error('Update failed')
    }
  }

  const deleteUser = async (u) => {
    if (!confirm(`Delete user "${u.username}"? This cannot be undone.`)) return
    try {
      await api.delete(`/admin/users/${u.id}`)
      toast.success('User deleted')
      load()
    } catch (err) {
      toast.error(err.response?.data?.error || 'Delete failed')
    }
  }

  if (loading) return <Loader fullscreen />

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 animate-fadeIn">
      <Link to="/admin" className="text-primary text-sm hover:underline">← Admin Panel</Link>
      <h1 className="text-3xl font-extrabold mt-1 mb-6">Manage Users</h1>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-surface2 text-slate-400">
            <tr>
              <th className="text-left px-4 py-3">Username</th>
              <th className="text-left px-4 py-3 hidden sm:table-cell">Email</th>
              <th className="text-right px-4 py-3">Points</th>
              <th className="text-center px-4 py-3">Role</th>
              <th className="text-right px-4 py-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-t border-border">
                <td className="px-4 py-3 font-medium">{u.username}</td>
                <td className="px-4 py-3 hidden sm:table-cell text-slate-400">{u.email}</td>
                <td className="px-4 py-3 text-right text-primary font-bold">{u.points}</td>
                <td className="px-4 py-3 text-center">
                  <button onClick={() => toggleAdmin(u)} className={`inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full border ${u.is_admin ? 'border-accent/40 text-accent' : 'border-border text-slate-400'}`}>
                    {u.is_admin ? <FaUserShield /> : <FaUser />} {u.is_admin ? 'Admin' : 'User'}
                  </button>
                </td>
                <td className="px-4 py-3 text-right">
                  <button onClick={() => deleteUser(u)} disabled={u.id === currentUser.id} className="text-danger disabled:opacity-30"><FaTrash /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
