import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { FaFlag, FaUsers, FaTrophy, FaLayerGroup, FaBullhorn, FaTrashAlt, FaFileExport, FaShieldAlt } from 'react-icons/fa'
import api from '../../api/axios'
import Loader from '../../components/Loader'

export default function AdminPanel() {
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.get('/admin/stats').then((res) => setStats(res.data)).finally(() => setLoading(false))
  }, [])

  const handleReset = async () => {
    if (!confirm('This will wipe all solves and reset every score to 0. Continue?')) return
    try {
      await api.post('/admin/scoreboard/reset')
      toast.success('Scoreboard reset')
    } catch (err) {
      toast.error('Reset failed')
    }
  }

  const handleExport = async () => {
    try {
      const res = await api.get('/admin/export')
      const blob = new Blob([JSON.stringify(res.data, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'tamayoz_export.json'
      a.click()
      URL.revokeObjectURL(url)
      toast.success('Database exported')
    } catch (err) {
      toast.error('Export failed')
    }
  }

  if (loading) return <Loader fullscreen />

  const cards = [
    { label: 'Players', value: stats.userCount, icon: <FaUsers />, color: 'text-primary' },
    { label: 'Challenges', value: stats.challengeCount, icon: <FaFlag />, color: 'text-secondary' },
    { label: 'Solves', value: stats.solveCount, icon: <FaTrophy />, color: 'text-warning' },
    { label: 'Teams', value: stats.teamCount, icon: <FaLayerGroup />, color: 'text-accent' }
  ]

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 animate-fadeIn">
      <h1 className="text-3xl font-extrabold mb-8 flex items-center gap-3"><FaShieldAlt className="text-accent" /> Admin Panel</h1>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {cards.map((c) => (
          <motion.div key={c.label} whileHover={{ y: -3 }} className="card p-5">
            <div className={`text-2xl mb-2 ${c.color}`}>{c.icon}</div>
            <p className="text-2xl font-bold">{c.value}</p>
            <p className="text-slate-400 text-sm">{c.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        <Link to="/admin/challenges" className="card p-6 hover:border-primary/50 transition-all flex items-center gap-3">
          <FaFlag className="text-primary text-xl" /> Manage Challenges
        </Link>
        <Link to="/admin/users" className="card p-6 hover:border-primary/50 transition-all flex items-center gap-3">
          <FaUsers className="text-primary text-xl" /> Manage Users
        </Link>
        <Link to="/admin/announcements" className="card p-6 hover:border-primary/50 transition-all flex items-center gap-3">
          <FaBullhorn className="text-primary text-xl" /> Announcements
        </Link>
      </div>

      <div className="card p-6 flex flex-col sm:flex-row gap-4">
        <button onClick={handleExport} className="btn-secondary flex items-center gap-2"><FaFileExport /> Export Database</button>
        <button onClick={handleReset} className="btn-danger flex items-center gap-2"><FaTrashAlt /> Reset Scoreboard</button>
      </div>
    </div>
  )
}
