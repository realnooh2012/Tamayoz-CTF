import React, { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { FaFlag, FaTrophy, FaUser, FaCog, FaSignOutAlt, FaBars, FaTimes, FaShieldAlt } from 'react-icons/fa'
import { useAuth } from '../context/AuthContext'

export default function Navbar() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [open, setOpen] = useState(false)

  const links = [
    { to: '/dashboard', label: 'Dashboard' },
    { to: '/challenges', label: 'Challenges', icon: <FaFlag /> },
    { to: '/scoreboard', label: 'Scoreboard', icon: <FaTrophy /> },
    { to: `/profile/${user?.username}`, label: 'Profile', icon: <FaUser /> }
  ]

  const handleLogout = () => {
    logout()
    navigate('/login')
  }

  if (!user) return null

  return (
    <nav className="sticky top-0 z-40 glass border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between h-16">
        <Link to="/dashboard" className="flex items-center gap-2 font-extrabold text-xl">
          <FaFlag className="text-primary" />
          <span className="gradient-text">Tamayoz</span>CTF
        </Link>

        <div className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                location.pathname === l.to ? 'text-primary bg-primary/10' : 'text-slate-300 hover:text-white hover:bg-surface2'
              }`}
            >
              {l.icon} {l.label}
            </Link>
          ))}
          {user.is_admin === 1 && (
            <Link to="/admin" className={`px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${location.pathname.startsWith('/admin') ? 'text-accent bg-accent/10' : 'text-slate-300 hover:text-white hover:bg-surface2'}`}>
              <FaShieldAlt /> Admin
            </Link>
          )}
        </div>

        <div className="hidden md:flex items-center gap-3">
          <span className="text-sm text-slate-400">
            <span className="text-primary font-bold">{user.points}</span> pts
          </span>
          <Link to="/settings" className="p-2 rounded-lg hover:bg-surface2 text-slate-300"><FaCog /></Link>
          <button onClick={handleLogout} className="p-2 rounded-lg hover:bg-surface2 text-slate-300"><FaSignOutAlt /></button>
        </div>

        <button className="md:hidden text-xl" onClick={() => setOpen(!open)}>
          {open ? <FaTimes /> : <FaBars />}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden border-t border-border overflow-hidden"
          >
            <div className="flex flex-col p-4 gap-1">
              {links.map((l) => (
                <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="px-3 py-2 rounded-lg text-slate-200 hover:bg-surface2">
                  {l.label}
                </Link>
              ))}
              {user.is_admin === 1 && (
                <Link to="/admin" onClick={() => setOpen(false)} className="px-3 py-2 rounded-lg text-accent hover:bg-surface2">Admin</Link>
              )}
              <Link to="/settings" onClick={() => setOpen(false)} className="px-3 py-2 rounded-lg text-slate-200 hover:bg-surface2">Settings</Link>
              <button onClick={handleLogout} className="px-3 py-2 rounded-lg text-left text-danger hover:bg-surface2">Logout</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  )
}
