import React from 'react'
import { motion } from 'framer-motion'
import { FaCheckCircle, FaLock, FaFlag } from 'react-icons/fa'
import { Link } from 'react-router-dom'

const difficultyColor = {
  easy: 'text-success border-success/40 bg-success/10',
  medium: 'text-warning border-warning/40 bg-warning/10',
  hard: 'text-danger border-danger/40 bg-danger/10'
}

export default function ChallengeCard({ challenge }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.25 }}
    >
      <Link
        to={`/challenges/${challenge.id}`}
        className={`block card p-5 h-full hover:border-primary/50 hover:shadow-glow transition-all duration-200 relative overflow-hidden ${challenge.solved ? 'border-success/40' : ''}`}
      >
        {challenge.solved && (
          <div className="absolute top-3 right-3 text-success text-lg">
            <FaCheckCircle />
          </div>
        )}
        <div className="flex items-center gap-2 mb-3">
          <span className="text-xs font-semibold px-2 py-0.5 rounded-full border" style={{ borderColor: challenge.category_color, color: challenge.category_color, backgroundColor: `${challenge.category_color}1a` }}>
            {challenge.category || 'Misc'}
          </span>
          <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${difficultyColor[challenge.difficulty] || difficultyColor.easy}`}>
            {challenge.difficulty || 'easy'}
          </span>
        </div>
        <h3 className="font-bold text-lg mb-2 line-clamp-1">{challenge.title}</h3>
        <div className="flex items-center justify-between mt-4">
          <span className="text-primary font-bold flex items-center gap-1">
            <FaFlag className="text-sm" /> {challenge.points} pts
          </span>
          <span className="text-xs text-slate-500">{challenge.solve_count} solve{challenge.solve_count !== 1 ? 's' : ''}</span>
        </div>
      </Link>
    </motion.div>
  )
}
