import React, { useState, useEffect } from 'react'

function getTimeParts(target) {
  const diff = Math.max(0, target - Date.now())
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24)
  const minutes = Math.floor((diff / (1000 * 60)) % 60)
  const seconds = Math.floor((diff / 1000) % 60)
  return { days, hours, minutes, seconds, ended: diff <= 0 }
}

export default function Countdown({ targetDate }) {
  const [time, setTime] = useState(() => getTimeParts(targetDate))

  useEffect(() => {
    const interval = setInterval(() => setTime(getTimeParts(targetDate)), 1000)
    return () => clearInterval(interval)
  }, [targetDate])

  if (time.ended) {
    return <span className="text-danger font-bold">Competition Ended</span>
  }

  const Box = ({ value, label }) => (
    <div className="flex flex-col items-center bg-surface2 border border-border rounded-lg px-3 py-2 min-w-[60px]">
      <span className="text-xl font-mono font-bold text-primary">{String(value).padStart(2, '0')}</span>
      <span className="text-[10px] uppercase text-slate-500">{label}</span>
    </div>
  )

  return (
    <div className="flex gap-2">
      <Box value={time.days} label="Days" />
      <Box value={time.hours} label="Hrs" />
      <Box value={time.minutes} label="Min" />
      <Box value={time.seconds} label="Sec" />
    </div>
  )
}
