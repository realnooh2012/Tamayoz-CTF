import React from 'react'
import { motion } from 'framer-motion'

export default function Loader({ fullscreen = false }) {
  const content = (
    <div className="flex flex-col items-center gap-3">
      <motion.div
        className="w-10 h-10 border-4 border-primary/30 border-t-primary rounded-full"
        animate={{ rotate: 360 }}
        transition={{ repeat: Infinity, duration: 0.8, ease: 'linear' }}
      />
      <span className="text-sm text-slate-400">Loading...</span>
    </div>
  )

  if (fullscreen) {
    return <div className="min-h-screen flex items-center justify-center bg-bg">{content}</div>
  }
  return <div className="flex items-center justify-center py-16">{content}</div>
}
