import React, { createContext, useContext, useEffect, useState } from 'react'
import { io } from 'socket.io-client'
import toast from 'react-hot-toast'
import { useAuth } from './AuthContext'

const SocketContext = createContext(null)

export function SocketProvider({ children }) {
  const [socket, setSocket] = useState(null)
  const { user } = useAuth()

  useEffect(() => {
    const s = io(import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000', {
      transports: ['websocket', 'polling']
    })
    setSocket(s)

    s.on('solve', (data) => {
      if (data.firstBlood) {
        toast.success(`🩸 First Blood! ${data.username} solved "${data.challenge}" (+${data.points})`, { duration: 5000 })
      } else {
        toast(`${data.username} solved "${data.challenge}" (+${data.points})`, { icon: '🚩' })
      }
    })

    s.on('announcement', (announcement) => {
      toast(`📢 ${announcement.title}`, { duration: 6000 })
    })

    return () => s.disconnect()
  }, [])

  return <SocketContext.Provider value={socket}>{children}</SocketContext.Provider>
}

export const useSocket = () => useContext(SocketContext)
