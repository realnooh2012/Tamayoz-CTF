import React, { createContext, useContext, useState, useEffect } from 'react'
import api from '../api/axios'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const stored = localStorage.getItem('tamayoz_user')
    return stored ? JSON.parse(stored) : null
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('tamayoz_token')
    if (!token) { setLoading(false); return }

    api.get('/auth/me')
      .then((res) => {
        setUser(res.data.user)
        localStorage.setItem('tamayoz_user', JSON.stringify(res.data.user))
      })
      .catch(() => {
        localStorage.removeItem('tamayoz_token')
        localStorage.removeItem('tamayoz_user')
        setUser(null)
      })
      .finally(() => setLoading(false))
  }, [])

  const login = async (username, password) => {
    const res = await api.post('/auth/login', { username, password })
    localStorage.setItem('tamayoz_token', res.data.token)
    localStorage.setItem('tamayoz_user', JSON.stringify(res.data.user))
    setUser(res.data.user)
    return res.data.user
  }

  const register = async (username, email, password) => {
    const res = await api.post('/auth/register', { username, email, password })
    localStorage.setItem('tamayoz_token', res.data.token)
    localStorage.setItem('tamayoz_user', JSON.stringify(res.data.user))
    setUser(res.data.user)
    return res.data.user
  }

  const logout = () => {
    localStorage.removeItem('tamayoz_token')
    localStorage.removeItem('tamayoz_user')
    setUser(null)
  }

  const updateUserPoints = (points) => {
    setUser((prev) => {
      const updated = { ...prev, points }
      localStorage.setItem('tamayoz_user', JSON.stringify(updated))
      return updated
    })
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, updateUserPoints }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
